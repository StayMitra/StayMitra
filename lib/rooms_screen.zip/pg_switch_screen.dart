import 'package:flutter/material.dart';
import 'building_model.dart';
//import 'database_helper.dart';
import 'pg_manager_service.dart';
import 'add_pg_screen.dart';
import 'models/property_model.dart';
import 'services/property_service.dart';
import 'services/user_access_service.dart';
class PgSwitchScreen extends StatefulWidget {
  final String ownerId;
  const PgSwitchScreen({
    super.key,
    required this.ownerId,
  });
  @override
  State<PgSwitchScreen> createState() => _PgSwitchScreenState();
}
class _PgSwitchScreenState extends State<PgSwitchScreen> {
  bool _loading = true;
  bool _selecting = false;
  bool _addingPg = false;
  bool _isOwner = false;
  List<BuildingModel> _pgs = [];
  @override
  void initState() {
    super.initState();
    _loadPgs();
  }
  // ------------------------------------------------------------
  // LOAD PGs
  // ------------------------------------------------------------
  //
  // Firebase is now the cloud source.
  //
  // Existing SQLite PGs are also loaded so that the current
  // application continues to work during migration.
  //
  // If the same PG exists in both Firebase and SQLite,
  // the same property/building ID is used and only one PG
  // is shown in the list.
  //
  // ------------------------------------------------------------
  Future<void> _loadPgs() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final access = UserAccessService.instance;
      final isOwner = await access.isOwner();

      // Load only Firebase properties allowed for this user.
      final properties =
          await PropertyService.instance.getProperties();

      final pgs = properties.map((property) {
        return BuildingModel(
          id: property.id,
          name: property.name,
          address: property.address.trim().isEmpty
              ? null
              : property.address,
          ownerId: property.ownerId,
          createdAt: property.createdAt,
        );
      }).toList();

      pgs.sort(
        (a, b) => a.name.toLowerCase().compareTo(
              b.name.toLowerCase(),
            ),
      );

      if (!mounted) return;

      setState(() {
        _isOwner = isOwner;
        _pgs = pgs;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _pgs = [];
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to load PGs: $e'),
        ),
      );
    }
  }

  // ------------------------------------------------------------
  // ADD NEW PG
  // ------------------------------------------------------------
  Future<void> _addPg() async {
    if (!_isOwner || _addingPg || _selecting) return;
    setState(() {
      _addingPg = true;
    });
    try {
      final created = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => AddPgScreen(
            ownerId: widget.ownerId,
          ),
        ),
      );
      if (!mounted) return;
      setState(() {
        _addingPg = false;
      });
      if (created == true) {
        // New PG is already selected as active PG.
        //
        // Close Switch PG and return to Dashboard.
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _addingPg = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Unable to add PG. ${e.toString()}',
          ),
        ),
      );
    }
  }
  // ------------------------------------------------------------
  // SELECT EXISTING PG
  // ------------------------------------------------------------
  Future<void> _selectPg(BuildingModel pg) async {
    if (_selecting || _addingPg) return;
    setState(() {
      _selecting = true;
    });
    try {
      // --------------------------------------------------------
      // Save selected PG as active PG.
      // --------------------------------------------------------
      //
      // Existing PgManagerService / PgContext flow is preserved.
      //
      // --------------------------------------------------------
      await PgManagerService.selectPg(
        pg,
        ownerId: pg.ownerId,
      );
      if (!mounted) return;
      // Return to Dashboard.
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _selecting = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Unable to switch PG. ${e.toString()}',
          ),
        ),
      );
    }
  }
  // ------------------------------------------------------------
  // CHECK ACTIVE PG
  // ------------------------------------------------------------
  bool _isActivePg(BuildingModel pg) {
    final activePg = PgManagerService.activePg;
    if (activePg == null) {
      return false;
    }
    return activePg.id == pg.id;
  }
  // ------------------------------------------------------------
  // SCREEN
  // ------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      // --------------------------------------------------------
      // APP BAR
      // --------------------------------------------------------
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF111827),
        leading: IconButton(
          tooltip: 'Back',
          onPressed: (_selecting || _addingPg)
              ? null
              : () => Navigator.pop(context, false),
          icon: const Icon(
            Icons.arrow_back_rounded,
          ),
        ),
        title: const Text(
          'Switch PG',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        // ------------------------------------------------------
        // ADD PG BUTTON
        // ------------------------------------------------------
        actions: [
          if (_isOwner)
            TextButton.icon(
              onPressed: (_selecting || _addingPg)
                  ? null
                  : _addPg,
              icon: const Icon(
                Icons.add_rounded,
                size: 20,
              ),
              label: const Text(
                'Add PG',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF2563EB),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
              ),
            ),
          const SizedBox(width: 8),
        ],
      ),
      // --------------------------------------------------------
      // BODY
      // --------------------------------------------------------
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : RefreshIndicator(
              onRefresh: _loadPgs,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                  16,
                  16,
                  16,
                  30,
                ),
                children: [
                  // ------------------------------------------
                  // YOUR PGs HEADER
                  // ------------------------------------------
                  _header(),
                  const SizedBox(height: 16),
                  // ------------------------------------------
                  // ADD PG CARD
                  // ------------------------------------------
                  if (_isOwner) _addPgCard(),
                  const SizedBox(height: 16),
                  // ------------------------------------------
                  // PG LIST
                  // ------------------------------------------
                  if (_pgs.isEmpty)
                    _emptyState()
                  else
                    ..._pgs.map(_pgCard),
                ],
              ),
            ),
      // --------------------------------------------------------
      // LOADING BOTTOM BAR
      // --------------------------------------------------------
      bottomSheet: (_selecting || _addingPg)
          ? Container(
              height: 56,
              width: double.infinity,
              color: Colors.white,
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    _addingPg
                        ? 'Opening Add PG...'
                        : 'Switching PG...',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF475569),
                    ),
                  ),
                ],
              ),
            )
          : null,
    );
  }
  // ------------------------------------------------------------
  // HEADER
  // ------------------------------------------------------------
  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: const Row(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Color(0xFFEFF6FF),
            child: Icon(
              Icons.swap_horiz_rounded,
              color: Color(0xFF2563EB),
              size: 28,
            ),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your PGs',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF111827),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Select the PG you want to manage.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Tap a PG below to switch.',
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xFF94A3B8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  // ------------------------------------------------------------
  // ADD PG CARD
  // ------------------------------------------------------------
  Widget _addPgCard() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: (_selecting || _addingPg)
            ? null
            : _addPg,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFEFF6FF),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFBFDBFE),
            ),
          ),
          child: Row(
            children: [
              // ----------------------------------------------
              // ICON
              // ----------------------------------------------
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Icons.add_business_rounded,
                  color: Color(0xFF2563EB),
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              // ----------------------------------------------
              // TEXT
              // ----------------------------------------------
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Add New PG',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF111827),
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Add another PG to your account.',
                      style: TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              // ----------------------------------------------
              // ARROW
              // ----------------------------------------------
              const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 18,
                color: Color(0xFF2563EB),
              ),
            ],
          ),
        ),
      ),
    );
  }
  // ------------------------------------------------------------
  // PG CARD
  // ------------------------------------------------------------
  Widget _pgCard(BuildingModel pg) {
    final isActive = _isActivePg(pg);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isActive
              ? const Color(0xFF2563EB)
              : const Color(0xFFE5E7EB),
          width: isActive ? 1.5 : 1,
        ),
        boxShadow: isActive
            ? [
                BoxShadow(
                  color: const Color(0xFF2563EB).withValues(
                    alpha: 0.08,
                  ),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: (_selecting || _addingPg)
              ? null
              : () => _selectPg(pg),
          borderRadius: BorderRadius.circular(18),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // ------------------------------------------
                // BUILDING ICON
                // ------------------------------------------
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF6FF),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Icon(
                    Icons.apartment_rounded,
                    color: Color(0xFF2563EB),
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                // ------------------------------------------
                // PG DETAILS
                // ------------------------------------------
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              pg.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF111827),
                              ),
                            ),
                          ),
                          if (isActive) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding:
                                  const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFDCFCE7),
                                borderRadius:
                                    BorderRadius.circular(20),
                              ),
                              child: const Text(
                                'Active',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF15803D),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      // ------------------------------------
                      // LOCATION
                      // ------------------------------------
                      if (pg.address != null &&
                          pg.address!.trim().isNotEmpty) ...[
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on_outlined,
                              size: 15,
                              color: Color(0xFF94A3B8),
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                pg.address!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF64748B),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                      // ------------------------------------
                      // ACTIVE TEXT
                      // ------------------------------------
                      if (isActive) ...[
                        const SizedBox(height: 6),
                        const Text(
                          'Currently managing this PG',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF2563EB),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                // ------------------------------------------
                // ARROW / ACTIVE ICON
                // ------------------------------------------
                Icon(
                  isActive
                      ? Icons.check_circle_rounded
                      : Icons.chevron_right_rounded,
                  color: isActive
                      ? const Color(0xFF16A34A)
                      : const Color(0xFF94A3B8),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  // ------------------------------------------------------------
  // EMPTY STATE
  // ------------------------------------------------------------
  Widget _emptyState() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.apartment_outlined,
            size: 50,
            color: Color(0xFF94A3B8),
          ),
          const SizedBox(height: 12),
          const Text(
            'No PGs added yet',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Add your first PG to start managing it.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              color: Color(0xFF64748B),
            ),
          ),
          if (_isOwner) ...[
            const SizedBox(height: 16),
            ElevatedButton.icon(
            onPressed: (_selecting || _addingPg)
                ? null
                : _addPg,
            icon: const Icon(
              Icons.add_rounded,
            ),
            label: const Text(
              'Add PG',
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2563EB),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(
                horizontal: 22,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          ],
        ],
      ),
    );
  }
}
