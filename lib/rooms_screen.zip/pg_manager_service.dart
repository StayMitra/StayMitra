
import 'building_model.dart';
import 'pg_context.dart';
import 'services/property_service.dart';
import 'services/user_access_service.dart';

class PgManagerService {
  static Future<List<BuildingModel>> getAllPgs({
    required String ownerId,
  }) async {
    final properties =
        await PropertyService.instance.getProperties();

    final pgs = properties.map((property) {
      return BuildingModel(
        id: property.id,
        name: property.name,
        address: property.address.trim().isEmpty
            ? null
            : property.address,
        createdAt: property.createdAt,
        ownerId: property.ownerId,
      );
    }).toList();

    pgs.sort(
      (a, b) => a.name.toLowerCase().compareTo(
            b.name.toLowerCase(),
          ),
    );

    return pgs;
  }

  static Future<void> selectPg(
    BuildingModel pg, {
    required String ownerId,
  }) async {
    final access = UserAccessService.instance;

    final allowed =
        await access.canAccessProperty(pg.id);

    if (!allowed) {
      throw Exception(
        'You are not authorized to access this PG.',
      );
    }

    final actualOwnerId = await access.ownerId();

    if (actualOwnerId == null ||
        actualOwnerId != pg.ownerId) {
      throw Exception(
        'PG owner does not match the logged-in account.',
      );
    }

    PgContext.setActivePg(pg);
  }

  static BuildingModel? get activePg =>
      PgContext.activePg;

  static String? get activePgId =>
      PgContext.activePg?.id;
}
